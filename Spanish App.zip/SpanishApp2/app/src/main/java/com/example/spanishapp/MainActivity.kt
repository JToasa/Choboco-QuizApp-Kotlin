package com.example.spanishapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import androidx.lifecycle.ViewModelProviders

class MainActivity : AppCompatActivity() {
    private val spanishViewModule: spanishViewModule by lazy {
        ViewModelProviders.of(this).get(spanishViewModule::class.java)
    }


    private lateinit var startbutton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        startbutton = findViewById(R.id.start_button)


        //This will allow btn to call the spanish lesson activity when clicked
        startbutton.setOnClickListener{
            val intent = Intent(this,spanishLessonActivity::class.java)
            startActivity(intent)
        }



//PROGRAM DONE ONLY NEED TO EDIT DESIGN




    }
}
