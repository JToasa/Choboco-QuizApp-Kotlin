package com.example.spanishapp

import androidx.annotation.StringRes

data class Question (@StringRes val  textResId: Int)

data class Option (@StringRes val  textResId: Int, val answer:Boolean)