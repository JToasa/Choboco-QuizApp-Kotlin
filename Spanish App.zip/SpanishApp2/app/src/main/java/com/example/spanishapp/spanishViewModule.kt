package com.example.spanishapp

import androidx.lifecycle.ViewModel

private const val TAG = "spanishViewModule"
class spanishViewModule:ViewModel() {

    /*
    * This index will increment depending on questionBank List
    * */
    var countindex = 0

    //each radio button has its own index to change text depending on questionTextView
    var radio1 = 0
    var radio2 = 0
    var radio3 = 0
    var radio4 = 0
    var radio5 = 0


    //Score will store the amount of correct point
    var score = 0

    private val questionBank = listOf(
        Question(R.string.Question1),
        Question(R.string.Question2),
        Question(R.string.Question3)
    )

    private val radioBank1 = listOf(
        Option(R.string.correct_option1,true),
        Option(R.string.option1,false),
        Option(R.string.option2,false)
    )

    private val radioBank2 = listOf(
        Option(R.string.option3,false),
        Option(R.string.correct_option2,true),
        Option(R.string.option4,false)
    )
    private val radioBank3 = listOf(
        Option(R.string.option5,false),
        Option(R.string.option6,false),
        Option(R.string.correct_option3,true)
    )

//    Additional Question For Future Question


//    private val radioBank4 = listOf(
//        Option(R.string.option7,false),
//        Option(R.string.correct_option4,true),
//        Option(R.string.option8,false)
//    )
//    private val radioBank5 = listOf(
//        Option(R.string.correct_option5,true),
//        Option(R.string.option9,false),
//        Option(R.string.option10,false)
//    )

//    Functions to Update TextView Questions
   val currentAnsw:Boolean
        get() = radioBank1[radio1].answer

    val currentAnsw2:Boolean
        get() = radioBank2[radio2].answer

    val currentAnsw3:Boolean
        get() = radioBank3[radio3].answer



    val currentquestionText: Int
        get() = questionBank[countindex].textResId

    fun next(){
        countindex = (countindex+1)%questionBank.size
    }




//    Function to update Each radio group for each question.

    val currentRadioTextView: Int
        get() = radioBank1[radio1].textResId

    fun nextOption(){
        radio1 = (radio1+1)%radioBank1.size
    }

//      Function for radio2
    val currentRadioTextView2: Int
        get() = radioBank2[radio2].textResId

    fun nextOption2(){
        radio2 = (radio2+1)%radioBank2.size
    }


    //Radio 3

    val currentRadioTextView3: Int
        get() = radioBank3[radio3].textResId

    fun nextOption3(){
        radio3 = (radio3+1)%radioBank3.size
    }


}