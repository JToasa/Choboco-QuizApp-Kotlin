package com.example.spanishapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*
import androidx.lifecycle.ViewModelProviders
import kotlinx.android.synthetic.main.activity_spanish_lesson.*
import kotlinx.android.synthetic.main.spanishlessonland.*

class spanishLessonActivity : AppCompatActivity() {

    private val SpanishViewModule: spanishViewModule by lazy {
        ViewModelProviders.of(this).get(spanishViewModule::class.java)
    }

    private lateinit var nextbtn: Button

    private lateinit var radioGroup: RadioGroup
    private lateinit var radioButton1: RadioButton
    private lateinit var radioButton2: RadioButton
    private lateinit var radioButton3: RadioButton

    private lateinit var submitButton: Button

    private lateinit var radiotextView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_spanish_lesson)

        nextbtn = findViewById(R.id.next_Button)

        radioGroup = findViewById(R.id.radio_Group)
        radioButton1 = findViewById(R.id.radio_one)
        radioButton2 = findViewById(R.id.radio_two)
        radioButton3 = findViewById(R.id.radio_three)

        submitButton = findViewById(R.id.submit_Button)

        radiotextView = findViewById(R.id.QuestionView)


//      *****Could not figure out how to toast users selection*****
//
//        radioGroup.setOnCheckedChangeListener { group, checkedId ->
//
//            if (radioButton1.isChecked)
//                Toast.makeText(this,R.string.radio_btn1, Toast.LENGTH_SHORT).show()
//            if (checkedId == R.id.radio_two)
//                Toast.makeText(this,R.string.radio_btn2, Toast.LENGTH_SHORT).show()
//            if (checkedId == R.id.radio_three)
//                Toast.makeText(this,+ R.string.radio_btn3, Toast.LENGTH_SHORT).show()
//        }






        submitButton.setOnClickListener {

            if (radioButton1.isChecked){
                val answ = checkanswer(SpanishViewModule.currentAnsw)
                addPoint(SpanishViewModule.currentAnsw)
                Toast.makeText(this,answ,Toast.LENGTH_SHORT).show()
            }
            if (radioButton2.isChecked){
                val answ = checkanswer(SpanishViewModule.currentAnsw2)
                addPoint(SpanishViewModule.currentAnsw2)
                Toast.makeText(this,answ,Toast.LENGTH_SHORT).show()
            }
            if (radioButton3.isChecked){
                val answ = checkanswer(SpanishViewModule.currentAnsw3)
                addPoint(SpanishViewModule.currentAnsw3)
                Toast.makeText(this,answ,Toast.LENGTH_SHORT).show()
            }

            disableButton()

        }


        nextbtn.setOnClickListener {
            SpanishViewModule.next()
            SpanishViewModule.nextOption()
            SpanishViewModule.nextOption2()
            SpanishViewModule.nextOption3()
            updateQuestion()
            updateRadio()
            enableButton()
            showScore()



        }
        updateQuestion()

    }

/*
* Will UPDATE QUESTION
* */
    private fun updateQuestion(){

        val questionResId = SpanishViewModule.currentquestionText
        radiotextView.setText(questionResId)
    }

    private fun updateRadio(){
        val questionResId = SpanishViewModule.currentRadioTextView
        radioButton1.setText(questionResId)

        val questionResId2 = SpanishViewModule.currentRadioTextView2
        radioButton2.setText(questionResId2)

        val questionResId3 = SpanishViewModule.currentRadioTextView3
        radioButton3.setText(questionResId3)

    }

    /*
    * Checkanswer() will check each radio to 'true' and the parameter that is passed on
    * */
    private fun checkanswer(userAnswer: Boolean): Int{
        val correctRadio1 = true

        val answ = if (userAnswer==correctRadio1) {
            R.string.correctToast

        }
        else {
            R.string.incorrectToast
        }
        return answ

    }


    //addPoint Function will give 1 point to user of answer is correct
    private fun addPoint(userAnswer: Boolean){
        val correctRadio1 = true

        val answ = if (userAnswer==correctRadio1) {
            SpanishViewModule.score = (SpanishViewModule.score+1)

        }
        else {
            R.string.incorrectToast
        }


    }

//Enable and disable button when the submit but is pressed
    private fun disableButton(){
        radioButton1.isEnabled = false
        radioButton2.isEnabled = false
        radioButton3.isEnabled = false
        submitButton.isEnabled = false
    }


    private fun enableButton(){
        radioButton1.isEnabled = true
        radioButton2.isEnabled = true
        radioButton3.isEnabled = true
        submitButton.isEnabled = true
    }


    /*after all question is done, depending on the dev, showScore() will open
    the final score page to display Final Score
    */
    private fun showScore(){
        if (SpanishViewModule.countindex <=0){
            val intent = Intent(this, ScoreActivity::class.java)


            /*
            * Score is passed to ScoreActivity as string to display as TextView
            * */
            val score = SpanishViewModule.score.toString()
            intent.putExtra("score",score)
            startActivity(intent)
        }
    }

}
