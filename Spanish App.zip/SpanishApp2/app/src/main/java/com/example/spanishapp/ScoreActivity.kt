package com.example.spanishapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelProviders
import kotlinx.android.synthetic.main.activity_score.*

class ScoreActivity : AppCompatActivity() {

    private val SpanishViewModule: spanishViewModule by lazy {
        ViewModelProviders.of(this).get(spanishViewModule::class.java)
    }

    private lateinit var retakeBtn: Button
    private lateinit var displayBtn: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_score)
        retakeBtn = findViewById(R.id.retakeBtn)


        var intent = intent
        val score = intent.getStringExtra("score")
        val result = findViewById<TextView>(R.id.ShowScore)
        result.text = "Score: " + score




        retakeBtn.setOnClickListener {
//        Retake Button should reset score values to 0 and take user to the
//        Main Menu activity
            SpanishViewModule.score == 0
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

    }
}

